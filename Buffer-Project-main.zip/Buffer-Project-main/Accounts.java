package tourism;

public class Accounts 
{
   String acName;
   double totalWithoutHotel;
   double total;
   Accounts(String n,double totalWithoutHotel,double total){
	   this.acName=n;
	   this.totalWithoutHotel=totalWithoutHotel;
	   this.total=total;
   }
}
