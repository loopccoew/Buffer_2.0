package tourism;
import java.util.Iterator;
public class RegisteredUsers 
{
		   String cname;
		   String password;
		   char membership1;
		   
		  
		  RegisteredUsers(String cname,String password,char membership1)
		  {
			this.membership1=membership1;  
		    this.cname=cname;
		    this.password=password;  
		  }
	
}
