package tourism;
public class Admin 
{
	   String adminName;
	   String securityKey;
	   
	   Admin(String adminName,String securityKey)
	  {
	    this.adminName=adminName;
	    this.securityKey=securityKey;     
	  }
	
      
}

